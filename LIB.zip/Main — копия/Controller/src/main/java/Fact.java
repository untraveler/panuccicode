import com.google.gson.Gson;
import org.jetbrains.annotations.NotNull;


import javax.persistence.Id;
import java.util.*;


final class Fact {
    @NotNull
    Gson gson = new Gson();
    @NotNull
    Lib lib = new Lib();
    @NotNull
    String json = gson.toJson(lib);
    @NotNull
    List<Book> bo = lib.bookList();
    @NotNull
    List<Author> au = lib.authorList();


    public void init(@NotNull String par) {
        for (Author a : au) {
            for (Book b : bo) {
                if(par.equals(a.getName()) && a.getId() == b.getId()){
                    System.out.println(b.getName());
                }


            }

        }

    }
}