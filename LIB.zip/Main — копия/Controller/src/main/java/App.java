import org.jetbrains.annotations.NotNull;

public final class App  {

    public static void main(@NotNull String[] args)  {

        Fact fact = new Fact();
        fact.init("Mayne Reid");
        fact.init("Mayne Reid");
        fact.init("Mayne Reid");

    }
}
