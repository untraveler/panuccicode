import org.jetbrains.annotations.NotNull;
import java.util.*;

final class Lib {

    @NotNull
    public List<Author> authorList() {
        return Arrays.asList(
                new Author("Mayne Reid", 0),
                new Author("My indian Slave", 1),
                new Author("Lurk Moar", 2),
                new Author("My indian", 3)

        );
    }

    @NotNull
    public List<Book> bookList(){
        return Arrays.asList(
                new Book("Headless Horseman",0),
                new Book("The white Chief",0),
                new Book("How i spent my summer", 1),
                new Book("K.M. code", 1),
                new Book("Lots of articles",2),
                new Book("I dunno lol",2)
        );
    }
}
