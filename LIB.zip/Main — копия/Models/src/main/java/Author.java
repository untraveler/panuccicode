import org.jetbrains.annotations.NotNull;
import java.io.Serializable;


public final class Author implements Serializable {
    private int id;

    @NotNull
    private String name;

    public Author(@NotNull String name, int id) {
        this.id = id;
        this.name = name;
    }



    public int getId() {
        return id;
    }

    @NotNull
    public String getName() {
        return name;
    }

}
