import org.jetbrains.annotations.NotNull;
import java.io.Serializable;



final class Book implements Serializable {


    private int id;
    @NotNull
    private String name;
    public Book(@NotNull String name, int id) {
        this.id = id;
        this.name = name;
    }
    public int getId() {
        return id;
    }
    @NotNull
    public String getName() {
        return name;
    }


    public void setName(@NotNull String name) {
        this.name = name;
    }
}